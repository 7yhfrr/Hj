import time
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# --- الإعدادات ---
TOKEN = "8645585242:AAHyY6PCiy30RiZ93GD1KXKZhQCY0eWxtig"
OWNER_ID = 7820358194  # الآيدي الخاص بك
CHANNEL_ID = "@Axcsea"  # يوزر القناة العام
CHANNEL_URL = "https://t.me/Axcsea" # رابط القناة للمستخدمين

# --- قواعد البيانات في الذاكرة ---
user_stats = {}      
unique_users = set() 
total_actions = 0    
user_last_request = {}
COOLDOWN = 3600

# إعداد السجلات لرؤية الأخطاء في الكونسول
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# --- وظائف التتبع ---
def track_user(user_id, name, action="تفاعل"):
    global total_actions
    total_actions += 1
    unique_users.add(user_id)
    if user_id not in user_stats:
        user_stats[user_id] = {"name": name, "extractions": 0, "last_action": action}
    else:
        user_stats[user_id]["last_action"] = action
        user_stats[user_id]["name"] = name

# --- دالة التحقق من الاشتراك (المحسنة) ---
async def is_user_subscribed(context, user_id):
    try:
        # فحص حالة العضو في القناة
        member = await context.bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        # الحالات المقبولة: عضو، مشرف، أو مالك القناة
        return member.status in ["member", "administrator", "creator"]
    except Exception as e:
        # طباعة الخطأ في الكونسول لمعرفة السبب (بوت ليس أدمن مثلاً)
        logging.error(f"Error checking subscription for {user_id}: {e}")
        return False

# --- لوحات الأزرار (تصميم عصري بدون خطوط) ---
def get_subscribe_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("اشترك هنا", url=CHANNEL_URL)],
        [InlineKeyboardButton("تحقق من الاشتراك ✅", callback_data="verify_sub")]
    ])

def get_chips_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("INWI *6 🌐", callback_data="chip_INWI *6")],
        [InlineKeyboardButton("WIN *6 🚀", callback_data="chip_WIN *6")]
    ])

def get_apps_keyboard(chip_name):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 HTTP CUSTOM", callback_data=f"app_{chip_name}_HTTP CUSTOM")],
        [InlineKeyboardButton("📥 NPV TUNNEL", callback_data=f"app_{chip_name}_NPV TUNNEL")],
        [InlineKeyboardButton("📥 DARK TUNNEL", callback_data=f"app_{chip_name}_DARK TUNNEL")]
    ])

# --- الأوامر الأساسية ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    name = update.effective_user.first_name
    track_user(user_id, name, "فتح البوت")

    if await is_user_subscribed(context, user_id):
        await update.message.reply_text(
            f"<b>أهلاً بك {name} في قائمة الملفات ⚡</b>\n\nالرجاء اختيار نوع الشريحة المطلوبة:",
            reply_markup=get_chips_keyboard(),
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            f"<b>عذراً عزيزي {name}! ⚠️</b>\n\nيجب عليك الانضمام لقناة البوت أولاً.\n\n• القناة: <code>{CHANNEL_ID}</code>",
            reply_markup=get_subscribe_keyboard(),
            parse_mode="HTML"
        )

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return

    stats_msg = (
        "<b>📊 لوحة تحكم المالك</b>\n\n"
        f"👤 مستخدمين نشطين: <code>{len(unique_users)}</code>\n"
        f"⚡ إجمالي التفاعلات: <code>{total_actions}</code>\n"
        f"📂 ملفات مستخرجة: <code>{sum(u['extractions'] for u in user_stats.values())}</code>\n\n"
        "<b>آخر التحركات:</b>\n"
    )
    
    recent_users = list(user_stats.items())[-5:]
    for uid, data in reversed(recent_users):
        stats_msg += f"• {data['name']} -> {data['last_action']}\n"

    await update.message.reply_text(stats_msg, parse_mode="HTML")

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    name = query.from_user.first_name
    data = query.data

    if data == "verify_sub":
        if await is_user_subscribed(context, user_id):
            track_user(user_id, name, "نجح في التحقق")
            await query.answer("✨ تم التحقق!")
            await query.edit_message_text(
                "<b>قائمة الخدمات المتوفرة ⚡</b>\n\nاختر الشريحة:",
                reply_markup=get_chips_keyboard(),
                parse_mode="HTML"
            )
        else:
            # رسالة التنبيه المنبثقة
            await query.answer(
                "الاشتراك غير مكتمل ⚠️\n\nيرجى التأكد من الضغط على زر 'انضمام' داخل القناة أولاً.",
                show_alert=True
            )

    elif data.startswith("chip_"):
        chip = data.split("_")[1]
        track_user(user_id, name, f"اختار {chip}")
        await query.answer()
        await query.edit_message_text(
            f"<b>خدمة {chip} ⚙️</b>\n\nحدد التطبيق المطلوب استخراجه:",
            reply_markup=get_apps_keyboard(chip),
            parse_mode="HTML"
        )

    elif data.startswith("app_"):
        parts = data.split("_")
        chip, app_name = parts[1], parts[2]
        now = time.time()
        
        if now - user_last_request.get(user_id, 0) < COOLDOWN:
            rem = int((COOLDOWN - (now - user_last_request[user_id])) // 60)
            await query.answer(f"⏳ انتظر {rem} دقيقة قبل الطلب مجدداً.", show_alert=True)
            return

        file_map = {
            ("INWI *6", "HTTP CUSTOM"): "files/INWI.hc",
            ("INWI *6", "NPV TUNNEL"): "files/INWI.npvt",
            ("INWI *6", "DARK TUNNEL"): "files/INWI.dark",
            ("WIN *6", "HTTP CUSTOM"): "files/WIN.hc",
            ("WIN *6", "NPV TUNNEL"): "files/WIN.npvt",
            ("WIN *6", "DARK TUNNEL"): "files/WIN.dark",
        }

        file_path = file_map.get((chip, app_name))

        if file_path:
            try:
                await query.answer(f"🚀 جاري إرسال {app_name}...")
                with open(file_path, "rb") as doc:
                    await context.bot.send_document(
                        chat_id=user_id,
                        document=doc,
                        caption=f"✅ <b>تم استخراج الملف بنجاح!</b>\n\n• الشريحة: {chip}\n• التطبيق: {app_name}",
                        parse_mode="HTML"
                    )
                track_user(user_id, name, f"استخرج {app_name}")
                user_stats[user_id]["extractions"] += 1
                user_last_request[user_id] = now
            except FileNotFoundError:
                await query.answer("❌ الملف غير موجود في مجلد files.", show_alert=True)
            except Exception as e:
                logging.error(f"Send error: {e}")
                await query.answer("❌ خطأ أثناء الإرسال.", show_alert=True)
        else:
            await query.answer("⚠️ هذا الملف غير متاح حالياً.", show_alert=True)

# --- تشغيل البوت ---
if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("panel", admin_panel))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print("البوت يعمل الآن... استعمل /panel لمتابعة النشاط.")
    app.run_polling()
